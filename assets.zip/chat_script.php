



<teamMember info={{ 
img:'/images/bebo.jpg',
name:'bebo ammar',
position:'manager',
phone:'12345678',
email:'bebo2020@gmail.com',
}}
/>


		<!-- End Page -->

		<!-- Back to top -->
		<a href="#top" id="back-to-top" class="md-opjjpmhoiojifppkkcdabiobhakljdgm_doc"><i class="fa fa-angle-up"></i></a>

		<!-- Jquery js-->
		<script src="assets/js-dark/vendors/jquery-3.2.1.min.js"></script>

		<!--Bootstrap.min js-->
		<script src="assets/plugins/bootstrap/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!--Jquery Sparkline js-->
		<script src="assets/js-dark/vendors/jquery.sparkline.min.js"></script>

		<!-- Chart Circle js-->
		<script src="assets/js-dark/vendors/circle-progress.min.js"></script>

		<!-- Star Rating js-->
		<script src="assets/plugins/rating/jquery.rating-stars.js"></script>

		<!--Moment js-->
		<script src="assets/plugins/moment/moment.min.js"></script>

		<!-- Daterangepicker js-->
		<script src="assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

		<!-- Horizontal-menu js -->
		<script src="assets/plugins/horizontal-menu/horizontalmenu.js"></script>

		<!-- Sidebar Accordions js -->
		<script src="assets/plugins/accordion1/js/easyResponsiveTabs.js"></script>

		<!-- Custom scroll bar js-->
		<script src="assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		<!--Owl Carousel js -->
		<script src="assets/plugins/owl-carousel/owl.carousel.js"></script>
		<script src="assets/plugins/owl-carousel/owl-main.js"></script>

		<!-- Rightsidebar js -->
		<script src="assets/plugins/sidebar/sidebar.js"></script>

		<!-- Charts js-->
		<script src="assets/plugins/chart/chart.bundle-dark.js"></script>
		<script src="assets/plugins/chart/utils.js"></script>

		<!--Time Counter js-->
		<script src="assets/plugins/counters/jquery.missofis-countdown.js"></script>
		<script src="assets/plugins/counters/counter.js"></script>

		<!--Morris  Charts js-->
		<script src="assets/plugins/morris/raphael-min.js"></script>
		<script src="assets/plugins/morris/morris.js"></script>

		<!-- Custom-charts js-->
		<script src="assets/js-dark/index1.js"></script>

		<!-- Custom js-->
		<script src="assets/js-dark/custom.js"></script>
	
</div></body></html>
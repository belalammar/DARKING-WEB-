$tpl = 'include/header.php';
$css = 'style/style.css';
js = 'js/js';